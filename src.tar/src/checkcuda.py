from torch.utils.tensorboard import SummaryWriter

# 创建一个 SummaryWriter 实例
writer = SummaryWriter()